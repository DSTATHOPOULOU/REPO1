Dr. Jekyll: A scholarly website template.
===================

This Jekyll template is meant for young (or established) scholars who would like to set up a website quickly and have it remain stable in the future.

The template includes a built in bibliography using bibtex format that you can use to update your incredibly long publication list (knock on wood).
